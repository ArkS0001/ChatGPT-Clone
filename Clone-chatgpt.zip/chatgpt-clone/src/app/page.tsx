import { Header } from "@/components/Header";
import { ChatInput } from "@/components/ChatInput";
import { SuggestionButtons } from "@/components/SuggestionButtons";
import { Footer } from "@/components/Footer";

export default function Home() {
  return (
    <div className="flex flex-col h-[100vh] bg-[#fbfbfb]">
      <Header />
      <main className="flex-1 flex flex-col items-center justify-center p-4">
        <h1 className="text-3xl font-semibold mb-8 text-center">
          What can I help with?
        </h1>
        <ChatInput />
        <SuggestionButtons />
      </main>
      <Footer />
    </div>
  );
}
