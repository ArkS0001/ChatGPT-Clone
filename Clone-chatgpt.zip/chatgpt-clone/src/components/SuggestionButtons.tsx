import { Button } from "@/components/ui/button";
import { FileText, Sparkles, PenLine, BrainCircuit, MoreHorizontal } from "lucide-react";

export function SuggestionButtons() {
  const suggestions = [
    {
      icon: <FileText className="h-4 w-4 mr-2" />,
      text: "Summarize text",
      color: "bg-[#f2f2f2] hover:bg-[#e4e4e4]",
    },
    {
      icon: <Sparkles className="h-4 w-4 mr-2" />,
      text: "Surprise me",
      color: "bg-[#f2f5fb] hover:bg-[#e4eaf5]",
    },
    {
      icon: <PenLine className="h-4 w-4 mr-2" />,
      text: "Help me write",
      color: "bg-[#f3f2fb] hover:bg-[#e6e4f5]",
    },
    {
      icon: <BrainCircuit className="h-4 w-4 mr-2" />,
      text: "Brainstorm",
      color: "bg-[#f2f7f2] hover:bg-[#e4f0e4]",
    },
  ];

  return (
    <div className="w-full flex justify-center mt-4 gap-2 flex-wrap">
      {suggestions.map((suggestion, index) => (
        <Button
          key={index}
          variant="outline"
          className={`flex items-center rounded-full border-none text-sm ${suggestion.color}`}
        >
          {suggestion.icon}
          {suggestion.text}
        </Button>
      ))}
      <Button
        variant="outline"
        className="flex items-center rounded-full border-none text-sm bg-[#f2f2f2] hover:bg-[#e4e4e4]"
      >
        <MoreHorizontal className="h-4 w-4" />
        More
      </Button>
    </div>
  );
}
