import Link from "next/link";

export function Footer() {
  return (
    <footer className="w-full text-center text-sm text-gray-500 py-4">
      <p>
        By messaging ChatGPT, you agree to our{" "}
        <Link href="#" className="underline hover:text-gray-700">
          Terms
        </Link>{" "}
        and have read our{" "}
        <Link href="#" className="underline hover:text-gray-700">
          Privacy Policy
        </Link>
        .
      </p>
    </footer>
  );
}
