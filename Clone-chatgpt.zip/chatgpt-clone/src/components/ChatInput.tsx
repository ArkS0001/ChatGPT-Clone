import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Paperclip, Search, Lightbulb, Mic } from "lucide-react";

export function ChatInput() {
  return (
    <div className="w-full max-w-[650px] mx-auto">
      <div className="relative border rounded-xl bg-white shadow-sm">
        <div className="min-h-[56px] flex items-center pl-4 pr-14">
          <Input
            placeholder="Ask anything"
            className="border-0 focus-visible:ring-0 focus-visible:ring-offset-0 px-0 py-0 text-base"
          />
        </div>
        <div className="absolute right-3 bottom-[13px] flex items-center gap-1.5">
          <Button variant="ghost" size="icon" className="h-8 w-8 rounded-lg">
            <Paperclip className="h-5 w-5 text-gray-500" />
          </Button>
          <Button variant="ghost" size="icon" className="h-8 w-8 rounded-lg">
            <Search className="h-5 w-5 text-gray-500" />
          </Button>
          <Button variant="ghost" size="icon" className="h-8 w-8 rounded-lg">
            <Lightbulb className="h-5 w-5 text-gray-500" />
          </Button>
          <Button variant="ghost" size="icon" className="h-8 w-8 rounded-lg bg-black text-white hover:bg-gray-800">
            <Mic className="h-5 w-5" />
          </Button>
        </div>
      </div>
    </div>
  );
}
