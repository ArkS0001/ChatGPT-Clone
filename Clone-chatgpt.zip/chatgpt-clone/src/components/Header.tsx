import { Button } from "@/components/ui/button";
import Link from "next/link";

export function Header() {
  return (
    <header className="flex justify-between items-center p-4 w-full">
      <div className="flex items-center">
        <Button variant="ghost" className="font-semibold text-lg">
          ChatGPT
        </Button>
      </div>
      <div className="flex gap-2">
        <Button variant="ghost" className="rounded-full">
          Log in
        </Button>
        <Button className="rounded-full bg-black text-white hover:bg-gray-800">
          Sign up
        </Button>
      </div>
    </header>
  );
}
